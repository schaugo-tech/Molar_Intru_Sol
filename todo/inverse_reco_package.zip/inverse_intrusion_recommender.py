
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Inverse recommender for posterior single-tooth intrusion based on FE simulation data.

Core ideas
----------
1) Keep material as discrete labels: TPU / Multi / PETG.
2) Fit a smooth 2D surface for each material and each metric:
      z = f(material, alveolar_height, planned_intrusion)
   using RectBivariateSpline on the 4x4 FE grid.
3) Solve the inverse recommendation problem:
      input: bone height, desired actual intrusion and/or risk limit
      output: recommended material + planned step size
4) Export chart evidence:
      - comprehensive score surface
      - PDL_max surface
      - Disp_Z_17 surface
      - Disp_X_17 surface
   Each chart contains 3 independent material surfaces in one figure, and marks
   the recommended point on the corresponding surface.
5) Export motion payload for later frontend 3D usage:
      predicted crown-point displacement vectors for teeth 11-17.

This script is intended as the backend-algorithm prototype. It does not run FEA.
It interpolates / smooth-fits the existing FE response database.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy.interpolate import RectBivariateSpline


MATERIAL_MAP = {
    "TPU(soft)": "TPU",
    "MultiLayer": "Multi",
    "PETG(hard)": "PETG",
}
MATERIALS = ["TPU", "Multi", "PETG"]

KEY_SURFACE_METRICS = [
    "ComprehensiveScore",
    "PDL_max (kPa)",
    "Disp_Z_17",
    "Disp_X_17",
]

KEY_EXPORT_METRICS = [
    "PDL_max (kPa)",
    "牙槽脊顶应力 (Mpa)",
    "牙槽脊顶形变 (mm)",
    "Intrusion Efficacy",
    "Disp_Z_17",
    "Disp_X_17",
    "Disp_Y_17",
]

TOOTH_IDS = [17, 16, 15, 14, 13, 12, 11]


@dataclass
class RecommendationResult:
    recommended_material: str
    planned_intrusion_mm: float
    predicted_actual_intrusion_mm: float
    predicted_pdl_max_kpa: float
    predicted_disp_x17_mm: float
    predicted_disp_y17_mm: float
    predicted_adj_drift_rms_mm: float
    comprehensive_score: float
    within_risk_limit: Optional[bool]
    target_deviation_mm: Optional[float]
    note: str


class SurfaceModel:
    def __init__(self, heights: np.ndarray, steps: np.ndarray, values: np.ndarray) -> None:
        # 4x4 regular grid -> quadratic spline is stable and smooth enough.
        self.heights = np.asarray(heights, dtype=float)
        self.steps = np.asarray(steps, dtype=float)
        self.spline = RectBivariateSpline(self.heights, self.steps, values, kx=2, ky=2, s=0)

    def predict(self, height: float, step: float) -> float:
        return float(self.spline(height, step)[0, 0])


class InverseIntrusionRecommender:
    def __init__(self, df: pd.DataFrame) -> None:
        self.raw = self._prepare_dataframe(df)
        self.heights = np.array(sorted(self.raw["Alveolar height"].unique()), dtype=float)
        self.steps = np.array(sorted(self.raw["Planned Intrusion (mm)"].unique()), dtype=float)
        self.metric_names = self._collect_metric_names(self.raw)
        self.models = self._build_surface_models(self.raw)

    @staticmethod
    def _prepare_dataframe(df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["material"] = out["Aligner material"].map(MATERIAL_MAP)
        if out["material"].isna().any():
            missing = sorted(out.loc[out["material"].isna(), "Aligner material"].dropna().unique().tolist())
            raise ValueError(f"Unrecognized material labels: {missing}")

        out["AbsDisp_X_17"] = out["Disp_X_17"].abs()
        out["AbsDisp_Y_17"] = out["Disp_Y_17"].abs()

        adj_sq = np.zeros(len(out))
        for tid in [16, 15, 14, 13, 12, 11]:
            adj_sq += (
                out[f"Disp_X_{tid}"] ** 2
                + out[f"Disp_Y_{tid}"] ** 2
                + out[f"Disp_Z_{tid}"] ** 2
            )
        out["AdjDriftRMS"] = np.sqrt(adj_sq / 6.0)
        return out

    @staticmethod
    def _collect_metric_names(df: pd.DataFrame) -> List[str]:
        exclude = {"编号", "Aligner material", "material"}
        numeric = df.select_dtypes(include=[np.number]).columns.tolist()
        return [c for c in numeric if c not in exclude]

    def _build_surface_models(self, df: pd.DataFrame) -> Dict[str, Dict[str, SurfaceModel]]:
        models: Dict[str, Dict[str, SurfaceModel]] = {}
        for material in MATERIALS:
            sub = df[df["material"] == material].copy()
            models[material] = {}
            for metric in self.metric_names:
                pivot = (
                    sub.pivot(index="Alveolar height", columns="Planned Intrusion (mm)", values=metric)
                    .reindex(index=self.heights, columns=self.steps)
                )
                if pivot.isna().any().any():
                    raise ValueError(f"Missing grid values for {material} / {metric}")
                models[material][metric] = SurfaceModel(
                    heights=self.heights,
                    steps=self.steps,
                    values=pivot.values.astype(float),
                )
        return models

    def predict_metric(self, material: str, height: float, step: float, metric: str) -> float:
        material = self._normalize_material(material)
        self._validate_height_step(height, step)
        if metric not in self.models[material]:
            raise KeyError(f"Metric '{metric}' not found.")
        return self.models[material][metric].predict(height, step)

    @staticmethod
    def _normalize_material(material: str) -> str:
        if material not in MATERIALS:
            raise ValueError(f"Material must be one of {MATERIALS}, got {material!r}")
        return material

    def _validate_height_step(self, height: float, step: float) -> None:
        hmin, hmax = float(self.heights.min()), float(self.heights.max())
        smin, smax = float(self.steps.min()), float(self.steps.max())
        if not (hmin <= height <= hmax):
            raise ValueError(f"Alveolar height must be within [{hmin}, {hmax}]")
        if not (smin <= step <= smax):
            raise ValueError(f"Planned intrusion must be within [{smin}, {smax}]")

    def build_candidate_table(
        self,
        alveolar_height: float,
        target_actual_intrusion: Optional[float],
        risk_limit_kpa: Optional[float],
        search_points: int = 301,
        weights: Tuple[float, float, float] = (0.50, 0.35, 0.15),
    ) -> pd.DataFrame:
        if search_points < 25:
            raise ValueError("search_points must be >= 25 for stable recommendation.")
        sgrid = np.linspace(float(self.steps.min()), float(self.steps.max()), int(search_points))

        rows: List[Dict[str, Any]] = []
        for material in MATERIALS:
            for planned in sgrid:
                row = {
                    "material": material,
                    "planned_intrusion_mm": float(planned),
                    "Disp_Z_17": self.predict_metric(material, alveolar_height, planned, "Disp_Z_17"),
                    "PDL_max (kPa)": self.predict_metric(material, alveolar_height, planned, "PDL_max (kPa)"),
                    "Disp_X_17": self.predict_metric(material, alveolar_height, planned, "Disp_X_17"),
                    "Disp_Y_17": self.predict_metric(material, alveolar_height, planned, "Disp_Y_17"),
                    "AbsDisp_X_17": abs(self.predict_metric(material, alveolar_height, planned, "Disp_X_17")),
                    "AbsDisp_Y_17": abs(self.predict_metric(material, alveolar_height, planned, "Disp_Y_17")),
                    "AdjDriftRMS": self.predict_metric(material, alveolar_height, planned, "AdjDriftRMS"),
                }
                rows.append(row)
        cand = pd.DataFrame(rows)

        # Per-patient normalization: compare candidates under the same bone support condition.
        for col in ["Disp_Z_17", "PDL_max (kPa)", "AbsDisp_X_17", "AbsDisp_Y_17", "AdjDriftRMS"]:
            denom = float(cand[col].max() - cand[col].min())
            if denom < 1e-12:
                cand[f"{col}__norm"] = 0.0
            else:
                cand[f"{col}__norm"] = (cand[col] - cand[col].min()) / denom

        # Achievement subscore
        if target_actual_intrusion is not None:
            sigma_target = max(0.008, 0.15 * float(target_actual_intrusion))
            cand["score_target"] = np.exp(-((cand["Disp_Z_17"] - target_actual_intrusion) / sigma_target) ** 2)
            cand["target_deviation_mm"] = cand["Disp_Z_17"] - target_actual_intrusion
        else:
            cand["score_target"] = cand["Disp_Z_17__norm"]
            cand["target_deviation_mm"] = np.nan

        # Risk subscore
        if risk_limit_kpa is not None:
            sigma_risk = max(1.0, 0.12 * float(risk_limit_kpa))
            cand["score_risk"] = 1.0 / (1.0 + np.exp((cand["PDL_max (kPa)"] - risk_limit_kpa) / sigma_risk))
            cand["within_risk_limit"] = cand["PDL_max (kPa)"] <= risk_limit_kpa
        else:
            cand["score_risk"] = 1.0 - cand["PDL_max (kPa)__norm"]
            cand["within_risk_limit"] = True

        # Side-effect subscore:
        # - mesiodistal non-target component
        # - buccolingual non-target component
        # - average adjacent-tooth drift
        cand["phi_side"] = (
            0.50 * cand["AbsDisp_X_17__norm"]
            + 0.20 * cand["AbsDisp_Y_17__norm"]
            + 0.30 * cand["AdjDriftRMS__norm"]
        )
        cand["score_side"] = 1.0 - cand["phi_side"]

        w_target, w_risk, w_side = weights
        cand["ComprehensiveScore"] = 100.0 * (
            w_target * cand["score_target"]
            + w_risk * cand["score_risk"]
            + w_side * cand["score_side"]
        )
        return cand.sort_values(["ComprehensiveScore", "score_risk", "score_target"], ascending=False).reset_index(drop=True)

    def recommend(
        self,
        alveolar_height: float,
        target_actual_intrusion: Optional[float] = None,
        risk_limit_kpa: Optional[float] = None,
        search_points: int = 301,
    ) -> Tuple[RecommendationResult, pd.DataFrame]:
        cand = self.build_candidate_table(
            alveolar_height=alveolar_height,
            target_actual_intrusion=target_actual_intrusion,
            risk_limit_kpa=risk_limit_kpa,
            search_points=search_points,
        )

        if risk_limit_kpa is not None and bool(cand["within_risk_limit"].any()):
            pool = cand[cand["within_risk_limit"]].copy()
            note = "Found at least one candidate within the PDL risk limit. Recommendation selected from feasible set."
        elif risk_limit_kpa is not None:
            pool = cand.copy()
            note = "No candidate satisfies the PDL risk limit strictly. Returned the highest-score compromise."
        else:
            pool = cand.copy()
            note = "No hard PDL risk constraint was provided. Recommendation selected by the comprehensive score."

        best = pool.iloc[0]
        result = RecommendationResult(
            recommended_material=str(best["material"]),
            planned_intrusion_mm=float(best["planned_intrusion_mm"]),
            predicted_actual_intrusion_mm=float(best["Disp_Z_17"]),
            predicted_pdl_max_kpa=float(best["PDL_max (kPa)"]),
            predicted_disp_x17_mm=float(best["Disp_X_17"]),
            predicted_disp_y17_mm=float(best["Disp_Y_17"]),
            predicted_adj_drift_rms_mm=float(best["AdjDriftRMS"]),
            comprehensive_score=float(best["ComprehensiveScore"]),
            within_risk_limit=None if risk_limit_kpa is None else bool(best["within_risk_limit"]),
            target_deviation_mm=None if target_actual_intrusion is None else float(best["target_deviation_mm"]),
            note=note,
        )
        return result, cand

    def surface_grid(
        self,
        metric: str,
        alveolar_height: Optional[float] = None,
        target_actual_intrusion: Optional[float] = None,
        risk_limit_kpa: Optional[float] = None,
        grid_size: int = 80,
    ) -> Dict[str, Dict[str, Any]]:
        hgrid = np.linspace(float(self.heights.min()), float(self.heights.max()), int(grid_size))
        sgrid = np.linspace(float(self.steps.min()), float(self.steps.max()), int(grid_size))
        out: Dict[str, Dict[str, Any]] = {}

        if metric == "ComprehensiveScore":
            if alveolar_height is None:
                raise ValueError("alveolar_height must be provided when metric='ComprehensiveScore'")
            # Score surface depends on patient input. Here we compute it for all heights as well,
            # using the same patient-specific target/risk preferences.
            for material in MATERIALS:
                rows = []
                for h in hgrid:
                    row = []
                    cand = self.build_candidate_table(
                        alveolar_height=float(h),
                        target_actual_intrusion=target_actual_intrusion,
                        risk_limit_kpa=risk_limit_kpa,
                        search_points=grid_size,
                    )
                    sub = cand[cand["material"] == material].sort_values("planned_intrusion_mm")
                    interp = np.interp(sgrid, sub["planned_intrusion_mm"].to_numpy(), sub["ComprehensiveScore"].to_numpy())
                    row = interp.tolist()
                    rows.append(row)
                out[material] = {
                    "x_heights": hgrid.tolist(),
                    "y_planned_intrusion": sgrid.tolist(),
                    "z_values": rows,
                }
            return out

        for material in MATERIALS:
            rows = []
            for h in hgrid:
                row = [self.predict_metric(material, float(h), float(s), metric) for s in sgrid]
                rows.append(row)
            out[material] = {
                "x_heights": hgrid.tolist(),
                "y_planned_intrusion": sgrid.tolist(),
                "z_values": rows,
            }
        return out

    def predicted_motion_payload(self, material: str, height: float, step: float) -> Dict[str, Any]:
        material = self._normalize_material(material)
        self._validate_height_step(height, step)

        teeth_payload = []
        for tid in TOOTH_IDS:
            teeth_payload.append(
                {
                    "tooth_id": tid,
                    "disp_x_mm": self.predict_metric(material, height, step, f"Disp_X_{tid}"),
                    "disp_y_mm": self.predict_metric(material, height, step, f"Disp_Y_{tid}"),
                    "disp_z_mm": self.predict_metric(material, height, step, f"Disp_Z_{tid}"),
                }
            )

        return {
            "material": material,
            "alveolar_height": height,
            "planned_intrusion_mm": step,
            "note": (
                "This payload contains crown-point displacement vectors only. "
                "It is suitable for arrow-based or tip-point preview, but not yet for full rigid-body tooth motion."
            ),
            "teeth": teeth_payload,
        }

    def _compose_surface_figure(
        self,
        metric: str,
        surface_data: Dict[str, Dict[str, Any]],
        recommendation: RecommendationResult,
        alveolar_height: float,
        title: str,
        zaxis_title: str,
    ) -> go.Figure:
        fig = go.Figure()

        # Distinguish surfaces with different colorscales and transparency.
        # These are internal script outputs, not final response styling.
        colorscales = {
            "TPU": "Blues",
            "Multi": "Greens",
            "PETG": "Reds",
        }

        for material in MATERIALS:
            x = np.array(surface_data[material]["x_heights"])
            y = np.array(surface_data[material]["y_planned_intrusion"])
            z = np.array(surface_data[material]["z_values"])
            xx, yy = np.meshgrid(x, y, indexing="ij")
            fig.add_trace(
                go.Surface(
                    x=xx,
                    y=yy,
                    z=z,
                    name=material,
                    colorscale=colorscales[material],
                    showscale=False,
                    opacity=0.72,
                    hovertemplate=(
                        "Material=%s<br>Bone height=%%{x:.3f}<br>Planned step=%%{y:.4f} mm"
                        "<br>%s=%%{z:.4f}<extra></extra>" % (material, zaxis_title)
                    ),
                )
            )

        # Recommended point marker
        if metric == "ComprehensiveScore":
            rec_z = recommendation.comprehensive_score
        elif metric == "PDL_max (kPa)":
            rec_z = recommendation.predicted_pdl_max_kpa
        elif metric == "Disp_Z_17":
            rec_z = recommendation.predicted_actual_intrusion_mm
        elif metric == "Disp_X_17":
            rec_z = recommendation.predicted_disp_x17_mm
        else:
            rec_z = self.predict_metric(
                recommendation.recommended_material,
                alveolar_height,
                recommendation.planned_intrusion_mm,
                metric,
            )

        fig.add_trace(
            go.Scatter3d(
                x=[alveolar_height],
                y=[recommendation.planned_intrusion_mm],
                z=[rec_z],
                mode="markers+text",
                name="Recommended point",
                text=["Recommended"],
                textposition="top center",
                marker=dict(size=7, color="black", symbol="diamond"),
                hovertemplate=(
                    "Recommended<br>Material=%s<br>Bone height=%%{x:.3f}"
                    "<br>Planned step=%%{y:.4f} mm<br>%s=%%{z:.4f}<extra></extra>"
                    % (recommendation.recommended_material, zaxis_title)
                ),
            )
        )

        fig.update_layout(
            title=title,
            scene=dict(
                xaxis_title="Alveolar height",
                yaxis_title="Planned intrusion (mm)",
                zaxis_title=zaxis_title,
            ),
            template="plotly_white",
            legend=dict(x=0.02, y=0.98),
            margin=dict(l=0, r=0, b=0, t=40),
        )
        return fig

    def write_html_outputs(
        self,
        outdir: Path,
        alveolar_height: float,
        recommendation: RecommendationResult,
        target_actual_intrusion: Optional[float],
        risk_limit_kpa: Optional[float],
        grid_size: int = 80,
    ) -> Dict[str, str]:
        outdir.mkdir(parents=True, exist_ok=True)

        score_surface = self.surface_grid(
            metric="ComprehensiveScore",
            alveolar_height=alveolar_height,
            target_actual_intrusion=target_actual_intrusion,
            risk_limit_kpa=risk_limit_kpa,
            grid_size=grid_size,
        )
        pdl_surface = self.surface_grid(metric="PDL_max (kPa)", grid_size=grid_size)
        z_surface = self.surface_grid(metric="Disp_Z_17", grid_size=grid_size)
        x_surface = self.surface_grid(metric="Disp_X_17", grid_size=grid_size)

        fig_score = self._compose_surface_figure(
            metric="ComprehensiveScore",
            surface_data=score_surface,
            recommendation=recommendation,
            alveolar_height=alveolar_height,
            title="Comprehensive Score Surface (patient-conditioned)",
            zaxis_title="Comprehensive score",
        )
        fig_pdl = self._compose_surface_figure(
            metric="PDL_max (kPa)",
            surface_data=pdl_surface,
            recommendation=recommendation,
            alveolar_height=alveolar_height,
            title="PDL_max Surface",
            zaxis_title="PDL_max (kPa)",
        )
        fig_z = self._compose_surface_figure(
            metric="Disp_Z_17",
            surface_data=z_surface,
            recommendation=recommendation,
            alveolar_height=alveolar_height,
            title="Actual Intrusion Surface of Tooth 17",
            zaxis_title="Disp_Z_17 (mm)",
        )
        fig_x = self._compose_surface_figure(
            metric="Disp_X_17",
            surface_data=x_surface,
            recommendation=recommendation,
            alveolar_height=alveolar_height,
            title="Mesiodistal Displacement Surface of Tooth 17",
            zaxis_title="Disp_X_17 (mm)",
        )

        files = {
            "score_surface_html": str(outdir / "score_surface.html"),
            "pdl_surface_html": str(outdir / "pdl_surface.html"),
            "dispz_surface_html": str(outdir / "dispz17_surface.html"),
            "dispx_surface_html": str(outdir / "dispx17_surface.html"),
        }
        fig_score.write_html(files["score_surface_html"], include_plotlyjs="cdn")
        fig_pdl.write_html(files["pdl_surface_html"], include_plotlyjs="cdn")
        fig_z.write_html(files["dispz_surface_html"], include_plotlyjs="cdn")
        fig_x.write_html(files["dispx_surface_html"], include_plotlyjs="cdn")
        return files

    def export_surface_payload(
        self,
        outpath: Path,
        alveolar_height: float,
        target_actual_intrusion: Optional[float],
        risk_limit_kpa: Optional[float],
        grid_size: int = 80,
    ) -> None:
        payload = {
            "patient_conditioned_score_surface": self.surface_grid(
                metric="ComprehensiveScore",
                alveolar_height=alveolar_height,
                target_actual_intrusion=target_actual_intrusion,
                risk_limit_kpa=risk_limit_kpa,
                grid_size=grid_size,
            ),
            "pdl_surface": self.surface_grid(metric="PDL_max (kPa)", grid_size=grid_size),
            "dispz17_surface": self.surface_grid(metric="Disp_Z_17", grid_size=grid_size),
            "dispx17_surface": self.surface_grid(metric="Disp_X_17", grid_size=grid_size),
        }
        outpath.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Inverse recommendation prototype for posterior intrusion.")
    parser.add_argument("--data", type=str, required=True, help="Path to the Excel data file.")
    parser.add_argument("--outdir", type=str, required=True, help="Directory for outputs.")
    parser.add_argument("--bone-height", type=float, required=True, help="Alveolar height, e.g. 0.58 / 0.66 / 1.00")
    parser.add_argument("--target-intrusion", type=float, default=None, help="Desired actual intrusion of tooth 17 in mm.")
    parser.add_argument("--risk-limit", type=float, default=None, help="Upper limit of PDL_max in kPa.")
    parser.add_argument("--search-points", type=int, default=301, help="Search density along planned intrusion.")
    parser.add_argument("--grid-size", type=int, default=80, help="Surface grid resolution for chart export.")
    parser.add_argument("--top-n", type=int, default=12, help="How many ranked candidates to export.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_path = Path(args.data)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_excel(data_path)
    engine = InverseIntrusionRecommender(df)

    rec, ranking = engine.recommend(
        alveolar_height=float(args.bone_height),
        target_actual_intrusion=args.target_intrusion,
        risk_limit_kpa=args.risk_limit,
        search_points=int(args.search_points),
    )

    summary = {
        "input": {
            "bone_height": float(args.bone_height),
            "target_actual_intrusion_mm": args.target_intrusion,
            "risk_limit_kpa": args.risk_limit,
            "search_points": int(args.search_points),
            "grid_size": int(args.grid_size),
        },
        "recommendation": rec.__dict__,
        "scoring_formula": {
            "comprehensive_score": (
                "100 * (0.50 * score_target + 0.35 * score_risk + 0.15 * score_side)"
            ),
            "score_target": (
                "exp(-((Disp_Z_17 - target_actual_intrusion) / sigma_target)^2) "
                "if target is provided; otherwise min-max normalized Disp_Z_17"
            ),
            "score_risk": (
                "1 / (1 + exp((PDL_max - risk_limit) / sigma_risk)) "
                "if risk limit is provided; otherwise inverse min-max normalized PDL_max"
            ),
            "score_side": (
                "1 - (0.50*norm(|Disp_X_17|) + 0.20*norm(|Disp_Y_17|) + 0.30*norm(AdjDriftRMS))"
            ),
            "sigma_target_rule": "max(0.008, 0.15 * target_actual_intrusion)",
            "sigma_risk_rule": "max(1.0, 0.12 * risk_limit_kpa)",
        },
        "notes": [
            "Material is treated as a discrete label: TPU / Multi / PETG.",
            "Surfaces are built separately for each material.",
            "The score surface is patient-conditioned: it depends on target_actual_intrusion and/or risk_limit_kpa.",
            "This algorithm interpolates / smooth-fits the FE response database. It does not replace FEA outside the observed variable range.",
        ],
    }
    (outdir / "recommendation_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    ranking_export = ranking.copy()
    ranking_export.insert(0, "rank", np.arange(1, len(ranking_export) + 1))
    ranking_export.head(int(args.top_n)).to_csv(outdir / "candidate_rankings_topN.csv", index=False, encoding="utf-8-sig")

    engine.export_surface_payload(
        outpath=outdir / "surface_payload.json",
        alveolar_height=float(args.bone_height),
        target_actual_intrusion=args.target_intrusion,
        risk_limit_kpa=args.risk_limit,
        grid_size=int(args.grid_size),
    )

    motion = engine.predicted_motion_payload(
        material=rec.recommended_material,
        height=float(args.bone_height),
        step=rec.planned_intrusion_mm,
    )
    (outdir / "recommended_motion_payload.json").write_text(
        json.dumps(motion, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    html_files = engine.write_html_outputs(
        outdir=outdir,
        alveolar_height=float(args.bone_height),
        recommendation=rec,
        target_actual_intrusion=args.target_intrusion,
        risk_limit_kpa=args.risk_limit,
        grid_size=int(args.grid_size),
    )

    # Lightweight text summary for quick inspection
    lines = []
    lines.append("Inverse recommendation result")
    lines.append("===========================")
    lines.append(f"Bone height: {float(args.bone_height):.3f}")
    if args.target_intrusion is not None:
        lines.append(f"Target actual intrusion (mm): {float(args.target_intrusion):.4f}")
    if args.risk_limit is not None:
        lines.append(f"Risk limit PDL_max (kPa): {float(args.risk_limit):.4f}")
    lines.append("")
    lines.append(f"Recommended material: {rec.recommended_material}")
    lines.append(f"Recommended planned intrusion (mm): {rec.planned_intrusion_mm:.4f}")
    lines.append(f"Predicted actual intrusion of 17 (mm): {rec.predicted_actual_intrusion_mm:.4f}")
    lines.append(f"Predicted PDL_max (kPa): {rec.predicted_pdl_max_kpa:.4f}")
    lines.append(f"Predicted Disp_X_17 (mm): {rec.predicted_disp_x17_mm:.4f}")
    lines.append(f"Predicted Disp_Y_17 (mm): {rec.predicted_disp_y17_mm:.4f}")
    lines.append(f"Predicted adjacent drift RMS (mm): {rec.predicted_adj_drift_rms_mm:.4f}")
    lines.append(f"Comprehensive score: {rec.comprehensive_score:.2f}")
    lines.append(f"Within risk limit: {rec.within_risk_limit}")
    lines.append(f"Target deviation (mm): {rec.target_deviation_mm}")
    lines.append("")
    lines.append(f"Note: {rec.note}")
    lines.append("")
    lines.append("HTML outputs:")
    for k, v in html_files.items():
        lines.append(f"- {k}: {v}")
    (outdir / "README.txt").write_text("\n".join(lines), encoding="utf-8")

    print(json.dumps({
        "status": "ok",
        "outdir": str(outdir),
        "recommended_material": rec.recommended_material,
        "planned_intrusion_mm": rec.planned_intrusion_mm,
        "predicted_actual_intrusion_mm": rec.predicted_actual_intrusion_mm,
        "predicted_pdl_max_kpa": rec.predicted_pdl_max_kpa,
        "comprehensive_score": rec.comprehensive_score,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
