Inverse recommendation result
===========================
Bone height: 0.580
Target actual intrusion (mm): 0.0800
Risk limit PDL_max (kPa): 18.0000

Recommended material: TPU
Recommended planned intrusion (mm): 0.1583
Predicted actual intrusion of 17 (mm): 0.0794
Predicted PDL_max (kPa): 13.0218
Predicted Disp_X_17 (mm): -0.0091
Predicted Disp_Y_17 (mm): 0.0059
Predicted adjacent drift RMS (mm): 0.0106
Comprehensive score: 94.08
Within risk limit: True
Target deviation (mm): -0.0006421328053259345

Note: Found at least one candidate within the PDL risk limit. Recommendation selected from feasible set.

HTML outputs:
- score_surface_html: /mnt/data/inverse_reco_demo/score_surface.html
- pdl_surface_html: /mnt/data/inverse_reco_demo/pdl_surface.html
- dispz_surface_html: /mnt/data/inverse_reco_demo/dispz17_surface.html
- dispx_surface_html: /mnt/data/inverse_reco_demo/dispx17_surface.html